import React from "react";
const InternshipApply = () => (
  <div>
    <h3>Apply to Internship</h3>
    <form>
      <label>Why are you a good fit?<br />
        <textarea rows={4} />
      </label><br />
      <button type="submit">Submit Application</button>
    </form>
  </div>
);
export default InternshipApply;
