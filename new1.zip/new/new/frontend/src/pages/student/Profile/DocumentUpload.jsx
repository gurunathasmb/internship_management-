import React from "react";
const DocumentUpload = () => (
  <div>
    <h3>Upload Documents</h3>
    <input type="file" multiple />
    <button>Upload</button>
  </div>
);
export default DocumentUpload;
