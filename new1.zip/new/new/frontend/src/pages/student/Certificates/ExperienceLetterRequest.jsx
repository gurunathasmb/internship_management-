import React from "react";
const ExperienceLetterRequest = () => (
  <div>
    <h2>Request Experience Letter</h2>
    <form>
      <label>Company Name: <input type="text" /></label><br />
      <button type="submit">Request Letter</button>
    </form>
  </div>
);
export default ExperienceLetterRequest;
