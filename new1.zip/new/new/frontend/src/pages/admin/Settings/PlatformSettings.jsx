import React from "react";
const PlatformSettings = () => (
  <div>
    <h2>Platform Settings & Configuration</h2>
    <ul>
      <li>Set application deadlines</li>
      <li>Configure evaluation templates</li>
      <li>Enable/disable features (chat, auto-approval, etc.)</li>
    </ul>
    <p>[Settings panel coming soon!]</p>
  </div>
);
export default PlatformSettings;
