import React from "react";
const DocumentManagement = () => (
  <div>
    <h2>Document Management</h2>
    <ul>
      <li>Manage student reports, evaluations, certificates</li>
      <li>Approve/reject report submissions</li>
    </ul>
    <p>[Document tools coming soon!]</p>
  </div>
);
export default DocumentManagement;
