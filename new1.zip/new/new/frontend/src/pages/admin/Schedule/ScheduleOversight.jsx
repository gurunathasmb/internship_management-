import React from "react";
const ScheduleOversight = () => (
  <div>
    <h2>Schedule Oversight</h2>
    <ul>
      <li>View/manage interview schedules</li>
      <li>Coordinate dates with faculty/companies</li>
    </ul>
    <p>[Scheduling tools coming soon!]</p>
  </div>
);
export default ScheduleOversight;
