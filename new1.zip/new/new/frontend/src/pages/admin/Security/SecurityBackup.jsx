import React from "react";
const SecurityBackup = () => (
  <div>
    <h2>Security & Backup</h2>
    <ul>
      <li>Manage roles and permissions</li>
      <li>Backup/restore data</li>
      <li>Data retention and privacy compliance</li>
    </ul>
    <p>[Security tools coming soon!]</p>
  </div>
);
export default SecurityBackup;
