import React from "react";
const StudentOversight = () => (
  <div>
    <h2>Student Oversight</h2>
    <ul>
      <li>View progress of all students</li>
      <li>Assist/intervene if students face issues</li>
      <li>Mark internships as completed</li>
    </ul>
    <p>[Student management tools coming soon!]</p>
  </div>
);
export default StudentOversight;
