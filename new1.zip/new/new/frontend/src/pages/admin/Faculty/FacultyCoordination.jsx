import React from "react";
const FacultyCoordination = () => (
  <div>
    <h2>Faculty Coordination</h2>
    <ul>
      <li>Assign internship batches to faculty</li>
      <li>View/override faculty evaluations</li>
      <li>Flag pending tasks</li>
    </ul>
    <p>[Faculty tools coming soon!]</p>
  </div>
);
export default FacultyCoordination;
