import React from "react";
const CompanyAnalytics = () => (
  <div>
    <h2>Company Analytics</h2>
    <p>Applications per internship, conversion rates, feedback, etc. (coming soon!)</p>
  </div>
);
export default CompanyAnalytics;
