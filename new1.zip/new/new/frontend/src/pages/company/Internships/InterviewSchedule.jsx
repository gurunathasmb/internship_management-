import React from "react";
const InterviewSchedule = () => (
  <div>
    <h2>Interview Schedule</h2>
    <p>Schedule and manage interviews with applicants here.</p>
  </div>
);
export default InterviewSchedule;
