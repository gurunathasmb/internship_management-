import React from "react";
const CompanyAnnouncements = () => (
  <div>
    <h2>Announcements</h2>
    <p>Send announcements to selected intern groups (coming soon!)</p>
  </div>
);
export default CompanyAnnouncements;
