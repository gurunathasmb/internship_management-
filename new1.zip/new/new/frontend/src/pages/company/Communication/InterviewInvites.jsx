import React from "react";
const InterviewInvites = () => (
  <div>
    <h2>Interview Invites</h2>
    <p>Send interview invites to selected applicants (coming soon!)</p>
  </div>
);
export default InterviewInvites;
