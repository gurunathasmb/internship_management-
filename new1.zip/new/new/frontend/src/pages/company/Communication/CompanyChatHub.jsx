import React from "react";
const CompanyChatHub = () => (
  <div>
    <h2>Company Chat Hub</h2>
    <p>Chat with interns and assigned faculty (coming soon!)</p>
  </div>
);
export default CompanyChatHub;
