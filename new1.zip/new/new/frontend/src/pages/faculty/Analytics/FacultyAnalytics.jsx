import React from "react";
const FacultyAnalytics = () => (
  <div>
    <h2>Faculty Dashboard & Analytics</h2>
    <ul>
      <li>Track student applications (per student or batch)</li>
      <li>Monitor internship completion rates</li>
      <li>View company feedback on interns</li>
    </ul>
    <p>[Analytics charts coming soon!]</p>
  </div>
);
export default FacultyAnalytics;
