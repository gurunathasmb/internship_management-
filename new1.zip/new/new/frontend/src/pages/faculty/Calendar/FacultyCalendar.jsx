import React from "react";
const FacultyCalendar = () => (
  <div>
    <h2>Calendar & Deadlines</h2>
    <ul>
      <li>Set/report important internship dates</li>
      <li>View interview schedules relevant to your students</li>
    </ul>
    <p>[Calendar integration coming soon!]</p>
  </div>
);
export default FacultyCalendar;
