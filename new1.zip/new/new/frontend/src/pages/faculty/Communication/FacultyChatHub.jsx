import React from "react";
const FacultyChatHub = () => (
  <div>
    <h2>Communication & Coordination</h2>
    <p>Chat with students, companies, and admin here (coming soon!)</p>
  </div>
);
export default FacultyChatHub;
